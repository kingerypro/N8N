import json
import os
import sys
import pickle
from googleapiclient.discovery import build
from googleapiclient.http import MediaFileUpload
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request

# === CONFIGURATION ===
CLIENT_ID = "1033272910889-riefnfd8vistl9v0vsf8ufqcu45gmqqj.apps.googleusercontent.com"
CLIENT_SECRET = "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"
BINARY_VIDEO_PATH = "C:/Users/kinge/.n8n/binaryData/Final_Scene.bin"
MP4_PATH = BINARY_VIDEO_PATH.replace(".bin", ".mp4")
VIDEO_TITLE = sys.argv[1] if len(sys.argv) > 1 else "Untitled Video"
DESCRIPTION = "Generated via n8n automation."
CATEGORY_ID = "27"  # Education
PRIVACY_STATUS = "public"

SCOPES = ["https://www.googleapis.com/auth/youtube.upload"]
token_path = os.path.join(os.path.expanduser("~"), ".n8n", "token.pickle")

# === ENSURE FILE EXISTS ===
if not os.path.exists(BINARY_VIDEO_PATH):
    print(json.dumps({
        "success": False,
        "message": "❌ Video file not found at specified path"
    }))
    sys.exit(1)

# === AUTHENTICATION ===
creds = None
if os.path.exists(token_path):
    with open(token_path, "rb") as token:
        creds = pickle.load(token)

if not creds or not creds.valid:
    if creds and creds.expired and creds.refresh_token:
        creds.refresh(Request())
    else:
        os.environ['OAUTHLIB_INSECURE_TRANSPORT'] = '1'
        flow = InstalledAppFlow.from_client_config({
            "installed": {
                "client_id": CLIENT_ID,
                "client_secret": CLIENT_SECRET,
                "auth_uri": "https://accounts.google.com/o/oauth2/auth",
                "token_uri": "https://oauth2.googleapis.com/token",
                "redirect_uris": ["http://localhost"]
            }
        }, SCOPES)
        creds = flow.run_local_server(port=0)
    with open(token_path, "wb") as token:
        pickle.dump(creds, token)

youtube = build("youtube", "v3", credentials=creds)

# === UPLOAD VIDEO ===
try:
    request_body = {
        "snippet": {
            "title": VIDEO_TITLE,
            "description": DESCRIPTION,
            "categoryId": CATEGORY_ID
        },
        "status": {
            "privacyStatus": PRIVACY_STATUS
        }
    }

    with open(BINARY_VIDEO_PATH, 'rb') as bin_file:
        with open(MP4_PATH, 'wb') as mp4_file:
            mp4_file.write(bin_file.read())

    media_file = MediaFileUpload(MP4_PATH, mimetype="video/mp4", chunksize=1024*1024, resumable=True)
    request = youtube.videos().insert(part="snippet,status", body=request_body, media_body=media_file)

    response = None
    while response is None:
        status, response = request.next_chunk()
        if status:
            print(json.dumps({
                "success": True,
                "message": f"✅ Upload progress: {int(status.progress() * 100)}%"
            }))

    print(json.dumps({
        "success": True,
        "message": "✅ Upload completed successfully.",
        "videoId": response["id"]
    }))

    # === DELETE BOTH FILES ===
    deleted = []
    for f in [BINARY_VIDEO_PATH, MP4_PATH]:
        try:
            os.remove(f)
            deleted.append(f)
        except Exception as del_err:
            print(json.dumps({
                "warning": f"⚠️ Could not delete {f}: {str(del_err)}"
            }))

    print(json.dumps({
        "cleanup": True,
        "deleted_files": deleted
    }))

except Exception as e:
    print(json.dumps({
        "success": False,
        "message": f"❌ Upload failed: {str(e)}"
    }))
    sys.exit(1)
