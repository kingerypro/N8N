import os
import json

# Define the exact path you want to check
video_path = "C:/Users/kinge/.n8n/saved_audio/Final_Scene.mp4"

# Check if file exists
exists = os.path.exists(video_path)

# Print result as JSON
print(json.dumps({
    "exists": exists,
    "path": video_path,
    "message": "✅ File found" if exists else "❌ File not found"
}))
