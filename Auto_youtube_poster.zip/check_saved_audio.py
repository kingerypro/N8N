import os
import json

# Directories to scan
folders = {
    "saved_audio": "C:/Users/kinge/.n8n/saved_audio",
    "binaryData": "C:/Users/kinge/.n8n/binaryData"
}

deleted = []
failed = []
found = False

# Scan and delete .mp4 files from each folder
for label, path in folders.items():
    if not os.path.exists(path):
        continue
    for file in os.listdir(path):
        if file.lower().endswith(".mp4"):
            found = True
            full_path = os.path.join(path, file)
            try:
                os.remove(full_path)
                deleted.append(full_path)
            except Exception as e:
                failed.append({"file": full_path, "error": str(e)})

# Respond accordingly
if found:
    if failed:
        print(json.dumps({
            "success": False,
            "message": "⚠️ Some .mp4 files could not be deleted.",
            "deleted": deleted,
            "failed": failed
        }))
    else:
        print(json.dumps({
            "success": True,
            "message": "✅ All .mp4 files deleted successfully from both folders.",
            "deleted": deleted
        }))
else:
    print(json.dumps({
        "success": False,
        "message": "❌ No .mp4 files found in saved_audio or binaryData folders."
    }))
