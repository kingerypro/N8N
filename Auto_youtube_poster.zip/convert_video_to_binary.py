import os
import json

video_path = "C:/Users/kinge/.n8n/saved_audio/Final_Scene.mp4"
output_dir = "C:/Users/kinge/.n8n/binaryData"
binary_output = os.path.join(output_dir, "Final_Scene.bin")

# Ensure output folder exists
os.makedirs(output_dir, exist_ok=True)

# Check if video file exists
if not os.path.exists(video_path):
    print(json.dumps({
        "success": False,
        "message": "❌ Final_Scene.mp4 not found."
    }))
    exit(1)

try:
    # Read video as binary and write to .bin
    with open(video_path, "rb") as f:
        data = f.read()
    with open(binary_output, "wb") as out:
        out.write(data)

    print(json.dumps({
        "success": True,
        "message": "✅ Video converted to binary.",
        "output": binary_output,
        "BinaryPath": binary_output.replace("\\", "/")  # clean slash for n8n
    }))

except Exception as e:
    print(json.dumps({
        "success": False,
        "message": f"❌ Error: {str(e)}"
    }))
    exit(1)
