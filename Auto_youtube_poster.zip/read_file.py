import sys
import os
import io

folder = sys.argv[1]
file = sys.argv[2]

file_path = os.path.join("C:/xampp/htdocs", folder, file)

if not os.path.exists(file_path):
    print("::error::File not found")
    sys.exit(1)

# Force stdout to use UTF-8 for safe emoji/output handling
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

with open(file_path, "r", encoding="utf-8") as f:
    content = f.read()

print(content)
