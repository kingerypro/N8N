import os

SAVE_AUDIO_FOLDER = "saved_audio"
SAVE_IMAGE_FOLDER = "saved_images"
EXCLUDE_FILES = {"Final_Scene.mp4", "Final_Scene_Subtitled.mp4"}

def safe_print(msg):
    try:
        print(msg)
    except UnicodeEncodeError:
        print(msg.encode('ascii', errors='ignore').decode())

def clean_folder(folder_path, exclude_filenames=None):
    exclude_filenames = exclude_filenames or set()
    for filename in os.listdir(folder_path):
        file_path = os.path.join(folder_path, filename)
        if os.path.isfile(file_path) and filename not in exclude_filenames:
            try:
                os.remove(file_path)
                safe_print(f"[🧹] Deleted: {file_path}")
            except Exception as e:
                safe_print(f"[✖] Error deleting {file_path}: {e}")

def main():
    # Clean saved_images completely
    clean_folder(SAVE_IMAGE_FOLDER)

    # Clean saved_audio but keep Final_Scene.mp4 and Final_Scene_Subtitled.mp4
    clean_folder(SAVE_AUDIO_FOLDER, exclude_filenames=EXCLUDE_FILES)

if __name__ == "__main__":
    main()
