import sys
import asyncio
from edge_tts import Communicate
import edge_tts.exceptions
import pygame
import tempfile
import os

# Folder to save generated audio
SAVE_FOLDER = "saved_audio"
os.makedirs(SAVE_FOLDER, exist_ok=True)

async def speak_text(text, speaker, style="default"):
    speaker = speaker.lower()

    if "elara" in speaker:
        voice = "en-US-EmmaMultilingualNeural"
    elif "elias" in speaker:
        voice = "en-US-BrianNeural"
    elif "dorian" in speaker:
        voice = "en-US-AndrewNeural"
    else:
        voice = "en-US-AriaNeural"

    # Adjust speaking rate based on emotional style
    style = style.lower()
    rate = "+0%"

    if style in ["anxious", "urgent", "nervous"]:
        rate = "+20%"
    elif style in ["calm", "thoughtful", "reflective"]:
        rate = "-10%"
    elif style in ["sad", "concerned", "fearful"]:
        rate = "-15%"
    elif style in ["excited", "hopeful", "curious"]:
        rate = "+10%"

    try:
        # Create safe filename parts
        safe_speaker = speaker.replace(" ", "_").capitalize()
        safe_style = style.replace(" ", "_").capitalize()
        short_text = text[:30].replace(" ", "_").replace(".", "").replace(",", "").replace("’", "").replace("'", "")  # Clean and limit text
        filename = f"{safe_speaker}_{safe_style}_{short_text}.mp3"
        save_path = os.path.join(SAVE_FOLDER, filename)

        # Save the TTS to file
        communicate = Communicate(text, voice, rate=rate)
        await communicate.save(save_path)

        # Play it back
        pygame.mixer.init()
        pygame.mixer.music.load(save_path)
        pygame.mixer.music.play()

        while pygame.mixer.music.get_busy():
            pygame.time.wait(100)

        pygame.mixer.quit()

        print(f"✅ Saved and played: {save_path}")

    except edge_tts.exceptions.NoValidVoiceFound:
        print(f"❌ Error: Voice {voice} not found")
    except Exception as e:
        print(f"❌ Error: {str(e)}")

# Get CLI args
text = sys.argv[1]
speaker = sys.argv[2] if len(sys.argv) > 2 else "neutral"
style = sys.argv[3] if len(sys.argv) > 3 else "default"

# Run it
asyncio.run(speak_text(text, speaker, style))
