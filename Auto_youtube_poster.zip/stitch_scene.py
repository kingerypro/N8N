from pydub import AudioSegment
import os
import subprocess
import requests
import glob
import time
from datetime import timedelta


# Paths
FFMPEG_PATH = r"C:\Users\kinge\Downloads\ffmpeg-7.1.1-essentials_build\ffmpeg-7.1.1-essentials_build\bin\ffmpeg.exe"
FFPROBE_PATH = r"C:\Users\kinge\Downloads\ffmpeg-7.1.1-essentials_build\ffmpeg-7.1.1-essentials_build\bin\ffprobe.exe"

SAVE_AUDIO_FOLDER = "saved_audio"
SAVE_IMAGE_FOLDER = "saved_images"
OUTPUT_AUDIO_FILE = "scene_final.mp3"
OUTPUT_VIDEO_FILE = "Final_Scene.mp4"

PEXELS_API_KEY = "mYK8o3M2tUfFEWnQmVHlONcEX1Tm5qNFJvYKPMMdfYJYfOdvckGftr6v"

AudioSegment.converter = FFMPEG_PATH
AudioSegment.ffprobe = FFPROBE_PATH

os.makedirs(SAVE_AUDIO_FOLDER, exist_ok=True)
os.makedirs(SAVE_IMAGE_FOLDER, exist_ok=True)

def safe_print(msg):
    try:
        print(msg)
    except UnicodeEncodeError:
        print(msg.encode('ascii', errors='ignore').decode())

def fetch_image_for_clip(query_text, filename_hint):
    headers = {"Authorization": PEXELS_API_KEY}
    params = {"query": query_text, "per_page": 1}
    response = requests.get('https://api.pexels.com/v1/search', headers=headers, params=params)
    if response.status_code == 200:
        data = response.json()
        if data['photos']:
            img_url = data['photos'][0]['src']['large']
            img_path = os.path.join(SAVE_IMAGE_FOLDER, f"{filename_hint}.jpg")
            img_data = requests.get(img_url).content
            with open(img_path, 'wb') as f:
                f.write(img_data)
            safe_print(f"[✔] Image fetched for '{filename_hint}'")
        else:
            safe_print(f"[⚠] No images found for '{query_text}'")
    else:
        safe_print(f"[✖] Pexels API error for '{query_text}'")

def stitch_audio_and_fetch_images():
    clips = [
        os.path.join(SAVE_AUDIO_FOLDER, f)
        for f in os.listdir(SAVE_AUDIO_FOLDER)
        if f.endswith('.mp3') and f != OUTPUT_AUDIO_FILE
    ]
    clips = sorted(clips, key=lambda x: os.path.getctime(x))

    if not clips:
        safe_print("[✖] No MP3 files found in saved_audio/")
        return

    final_scene = AudioSegment.empty()

    for clip in clips:
        clip_name = os.path.basename(clip)
        clip_base, _ = os.path.splitext(clip_name)

        query_guess = clip_base.replace('_', ' ').replace('-', ' ')
        fetch_image_for_clip(query_guess, clip_base)

        audio = AudioSegment.from_file(clip, format="mp3")
        final_scene += audio + AudioSegment.silent(duration=500)

    output_path = os.path.join(SAVE_AUDIO_FOLDER, OUTPUT_AUDIO_FILE)
    final_scene.export(output_path, format="mp3", parameters=["-acodec", "libmp3lame"])
    safe_print(f"[✔] Combined audio saved to {output_path}")

def create_video_from_images_and_audio():
    audio_path = os.path.join(SAVE_AUDIO_FOLDER, OUTPUT_AUDIO_FILE)
    final_video_path = os.path.join(SAVE_AUDIO_FOLDER, OUTPUT_VIDEO_FILE)
    slideshow_path = os.path.join(SAVE_IMAGE_FOLDER, "slideshow.mp4")

    if not os.path.exists(audio_path):
        safe_print("[✖] Audio file not found!")
        return

    # Match audio clips to images
    audio_clips = sorted([
        os.path.join(SAVE_AUDIO_FOLDER, f)
        for f in os.listdir(SAVE_AUDIO_FOLDER)
        if f.endswith(".mp3") and f != OUTPUT_AUDIO_FILE
    ], key=lambda x: os.path.getctime(x))

    images = sorted(glob.glob(os.path.join(SAVE_IMAGE_FOLDER, "*.jpg")))
    if not images or not audio_clips:
        safe_print("[✖] Missing images or audio for slideshow")
        return

    if len(images) != len(audio_clips):
        safe_print("[⚠] Warning: Mismatch in image/audio count")

    # Get durations per clip
    durations = []
    for clip in audio_clips:
        audio = AudioSegment.from_file(clip, format="mp3")
        durations.append(audio.duration_seconds)

    # Create input.txt for slideshow with real durations
    input_txt_path = os.path.join(SAVE_IMAGE_FOLDER, "input.txt")
    with open(input_txt_path, "w") as f:
        for img, dur in zip(images, durations):
            f.write(f"file '{os.path.basename(img)}'\n")
            f.write(f"duration {dur + 0.5}\n")  # slight buffer between clips
        f.write(f"file '{os.path.basename(images[-1])}'\n")  # Repeat last frame to finalize

    safe_print(f"[✔] Created slideshow timeline with real audio sync")

    # Build slideshow
    subprocess.run([
        FFMPEG_PATH,
        "-y",
        "-f", "concat",
        "-safe", "0",
        "-i", input_txt_path,
        "-vf", f"scale=trunc(iw/2)*2:trunc(ih/2)*2",
        "-c:v", "libx264",
        "-pix_fmt", "yuv420p",
        slideshow_path
    ], check=True)

    # Merge slideshow + audio
    subprocess.run([
        FFMPEG_PATH,
        "-y",
        "-i", slideshow_path,
        "-i", audio_path,
        "-c:v", "copy",
        "-c:a", "aac",
        "-map", "0:v:0",
        "-map", "1:a:0",
        "-shortest",
        final_video_path
    ], check=True)

    safe_print(f"[🎬] Final video created with accurate image/audio/subtitle sync: {final_video_path}")


    try:
        # Build slideshow
        subprocess.run([
            FFMPEG_PATH,
            "-y",
            "-f", "concat",
            "-safe", "0", 
            "-i", input_txt_path,
            "-vf", f"scale=trunc(iw/2)*2:trunc(ih/2)*2",
            "-c:v", "libx264",
            "-pix_fmt", "yuv420p",
            slideshow_path
        ], check=True)

        # Merge slideshow + audio
        subprocess.run([
            FFMPEG_PATH,
            "-y",
            "-i", slideshow_path,
            "-i", audio_path,
            "-c:v", "copy", 
            "-c:a", "aac",
            "-map", "0:v:0",
            "-map", "1:a:0",
            "-shortest",
            final_video_path
        ], check=True)

        safe_print(f"[🎬] Final video created with accurate image/audio/subtitle sync: {final_video_path}")

    except Exception as e:
        safe_print(f"[✖] Error during video creation: {str(e)}")
        # Clean up temporary files
        for path in [input_txt_path, slideshow_path]:
            if os.path.exists(path):
                try:
                    os.remove(path)
                except Exception as cleanup_error:
                    safe_print(f"[⚠] Failed to clean up {path}: {str(cleanup_error)}")

def format_time(seconds: float) -> str:
    td = timedelta(seconds=round(seconds, 3))
    total_seconds = int(td.total_seconds())
    hours = total_seconds // 3600
    minutes = (total_seconds % 3600) // 60
    secs = total_seconds % 60
    milliseconds = int((seconds - int(seconds)) * 1000)
    return f"{hours:02}:{minutes:02}:{secs:02},{milliseconds:03}"

def generate_subtitles_file(clips, output_path="subtitles.srt"):
    srt_lines = []
    current_time = 0.0
    index = 1

    for clip in clips:
        clip_name = os.path.basename(clip)
        clip_base, _ = os.path.splitext(clip_name)

        text = clip_base.replace("_", " ").replace("-", " ")
        audio = AudioSegment.from_file(clip, format="mp3")
        duration = audio.duration_seconds
        start = format_time(current_time)
        end = format_time(current_time + duration)
        srt_lines.append(f"{index}\n{start} --> {end}\n{text}\n")
        current_time += duration + 0.5  # account for silence
        index += 1

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(srt_lines))

    safe_print("[📝] Subtitles file created.")


def burn_subtitles_into_video():
    input_video = os.path.join(SAVE_AUDIO_FOLDER, OUTPUT_VIDEO_FILE)
    output_video = os.path.join(SAVE_AUDIO_FOLDER, "Final_Scene_Subtitled.mp4")
    subtitles_file = "subtitles.srt"

    subprocess.run([
        FFMPEG_PATH,
        "-y",
        "-i", input_video,
        "-vf", f"subtitles={subtitles_file}",
        "-c:a", "copy",
        output_video
    ], check=True)
    safe_print(f"[🎞️] Subtitled video created at {output_video}")

def cleanup_after_render():
    for folder, keep_file in [
        (SAVE_AUDIO_FOLDER, OUTPUT_VIDEO_FILE),  # Keep final video only
        (SAVE_IMAGE_FOLDER, None)               # Delete everything
    ]:
        for file in os.listdir(folder):
            file_path = os.path.join(folder, file)
            if os.path.isfile(file_path):
                if keep_file and file == keep_file:
                    continue
                try:
                    os.remove(file_path)
                except Exception as e:
                    safe_print(f"[✖] Failed to delete {file_path}: {str(e)}")

def add_audio_waveform_overlay():
    input_video = os.path.join(SAVE_AUDIO_FOLDER, OUTPUT_VIDEO_FILE)
    overlay_output = os.path.join(SAVE_AUDIO_FOLDER, "Final_Scene_WithWaveform.mp4")

    subprocess.run([
        FFMPEG_PATH,
        "-y",
        "-i", input_video,
        "-filter_complex",
        "[0:a]showwaves=s=1280x100:mode=cline:rate=25:colors=cyan[sw];[0:v][sw]overlay=0:H-h-10",
        "-c:v", "libx264",
        "-c:a", "aac",
        "-strict", "experimental",
        "-shortest",
        overlay_output
    ], check=True)

    safe_print(f"[📊] Audio waveform overlay added: {overlay_output}")

    # Optional: Replace the base Final_Scene.mp4 with the waveform version
    os.replace(overlay_output, input_video)


def main():
    stitch_audio_and_fetch_images()
    clips = sorted([
        os.path.join(SAVE_AUDIO_FOLDER, f)
        for f in os.listdir(SAVE_AUDIO_FOLDER)
        if f.endswith('.mp3') and f != OUTPUT_AUDIO_FILE
    ], key=lambda x: os.path.getctime(x))

    generate_subtitles_file(clips)
    create_video_from_images_and_audio()
    add_audio_waveform_overlay()  # 👈 New step added here
    burn_subtitles_into_video()
    # cleanup_after_render()




if __name__ == "__main__":
    os.environ["PATH"] += os.pathsep + os.path.dirname(FFMPEG_PATH)
    main()
