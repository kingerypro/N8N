import sys
import os

# Get raw input from argument
raw_input = sys.argv[1]

# Decode newlines and quotes
content = raw_input.replace('\\n', '\n').replace('\\"', '"')

# Path to write to
temp_path = "C:/xampp/htdocs/temp_write.txt"

# Write to file
with open(temp_path, "w", encoding="utf-8") as f:
    f.write(content)

# Output ONLY the full file path
print(os.path.abspath(temp_path))
